# Handoff: Trade Assistant Dashboard Redesign

## Overview

Redesign of the personal trade-research dashboard described in `DESIGN_BRIEF.md`. The current app (Flask + one Jinja template, `assistant/web/templates/dashboard.html`) renders a single 31,639px-tall page: all 49 ideas as full expanded cards, no navigation, no responsive behavior, status encoded in hue only, and a paper/live safety model that has already caused one near-miss (a live account was briefly labelled "PAPER").

This bundle is **one coherent system of 11 screens**, not competing alternatives to choose between. If you're deciding "which is best" — there's no pick to make; each frame is a different view (or state) of the same app, sharing one sidebar IA (Today / Watchlist / Ideas / Journal) and one token set. The only literal alternates are 1d vs 1e (PAPER vs LIVE skin of the same order ticket) and 1i vs 1i2 (two states of the same phone view). 1j is not a screen at all — it's a spec sheet (colors, type, buttons, new API fields) for whoever builds this.

Implement all 11 in the existing stack: Python/Flask backend, server-rendered template, vanilla JS polling `GET /api/state`, no build step, no CDN (brief's explicit constraint — vendor fonts locally).

## About the Design Files

The bundled HTML files are **design references** — interactive HTML mockups showing intended look, copy, and behavior, not production code to copy directly. Recreate them in the target codebase (Flask/Jinja templates + vanilla JS, matching `dashboard.html`'s existing no-build-step convention) using the exact colors, type, spacing, and copy specified below and in the files themselves.

The files use a `{{ placeholder }}` templating syntax and custom tags (`<x-dc>`, `<sc-for>`) from the design tool they were built in — read them as annotated source (the inline `style="…"` attributes carry exact colors/spacing/copy) rather than trying to run them as-is. They will not render standalone outside that tool.

## Fidelity

**High-fidelity.** Every color, font size, spacing value, and piece of copy below is final, not placeholder. Recreate pixel-accurately.

## Screens / Views

### 1a — Today (landing, execution OFF)
**Purpose:** Daily glance: what changed, what needs a decision, portfolio state.
**Layout:** 232px sidebar + fluid main, both 1440×900. Main splits into a 3-row grid (header / body / footer). Body is `1fr 320px` — left column stacks "NEEDS YOUR DECISION" (triage cards) above "FLAGGED IN LAST SCAN" (table); right rail stacks Portfolio plate, Thesis-accuracy sparkline, Attention panel.
**Components:**
- Sidebar (shared across all desktop screens): logo block ("TRADE ASSISTANT" / "RESEARCH · v2"), nav (Today/Watchlist/Ideas/Journal, active item gets `background: var(--accent-dd)` + 2px left accent border, badge counts right-aligned), Order Entry status plate pinned to the bottom (bordered box with corner marks, dot + state word + one-line explainer + "Turn on…" link), Data-provider status list (3 rows: dot/glyph + name + freshness word).
- Header: "Today" (28px Barlow Condensed) + meta line ("Last scan 09:12 UTC · 27 tickers · 4 flagged · 3 new ideas"), right-aligned ticker-search input + ANALYZE (secondary) + RUN SCAN (primary, corner marks) buttons.
- Triage row (also reused in 1b, 1i): grid `96px 1fr 130px 96px`, left accent border colored by verdict, ticker (20px) + direction/id, verdict label + one-line thesis excerpt, R:R + max loss, confidence bar + number. Whole row is a link to 1c.
- Flagged table: TICKER/PRICE/CHG/VOL/RSI/SIGNALS columns, tabular-nums, change color-coded ok/bad.
- Portfolio plate: only card with all 4 corner marks. "$100,000" (32px), source line, exposure bar with cap tick mark, 2-up open-positions/risk-per-trade stat pair.
- Attention panel: degraded-provider and stale-idea callouts, glyph + bold headline + muted detail.
- Footer: disclaimer one-liner + "Full notice" link (→1h), freshness/legal meta, "Local only · 127.0.0.1:5002".

### 1b — Ideas (full queue, grouped by risk-gate verdict)
**Purpose:** The full 49-idea queue when Today's top-3 isn't enough.
**Layout:** Same shell. Header + filter chip row + scrollable grouped list.
**Components:** Ticker/company filter input, sort segmented control (VERDICT/CONFIDENCE/NEWEST). Chip row shows counts per verdict (Awaiting you·3, Approved·14, More research·8, Rejected·24, Open outcome·4, All·49) — active chip gets accent tint. Below, one `<section>` per verdict group (colored square bullet + title + note), rows are a 5-col grid (`104px 1fr 118px 104px 128px`): ticker/dir/id/age, thesis line, R:R/risk, confidence bar, decision word + "REVIEW →" pill. Rejected group is collapsed to a single dashed-border explainer row ("These failed a hard risk check… Show 24 rejected") — never expanded inline, since there's nothing to action.

### 1c — Idea detail (thesis left, plan + decision in a fixed rail)
**Purpose:** Everything needed to decide on one idea; the only place a decision or an order ticket originates.
**Layout:** Header (breadcrumb, ticker+direction+verdict pills, timestamp, prev/next), then `1fr 348px` — scrolling thesis column left, **fixed, non-scrolling** rail right.
**Components:**
- Thesis column: Thesis heading (model attribution inline), body paragraph (15px/1.62, max 68ch, inline `[source · date · freshness]` citations at 12.5px muted), Bull/Bear 2-up cards (ok/bad colored headers), Catalysts up/down 2-up list, 3-up Valuation/Balance-sheet/Data-gaps strip.
- Rail, top to bottom: **Trade plan** card (the other object with all 4 corner marks) — 2-col stat grid (entry zone, last price, stop in bad-color, target in ok-color, size + $ + %-of-book, max loss + %-of-book), reward:risk + confidence meter footer row, collapsible "Why 62 — three reasons". **Risk checks** card — glyph-led list, ok/warn colored. **Your decision** card — state label ("PENDING"), one primary button (APPROVE FOR MY WATCH, full-width, left-aligned label), two secondary buttons side by side (MORE RESEARCH / REJECT), helper line "Approving records your view. It places nothing." Dashed-border footnote explaining order entry is approved-ideas-only and names the current broker mode.
- Sidebar order-entry plate here shows the **ON·PAPER** state: warn-colored border/dot/corner-marks, account id, "TURN OFF" secondary button.

### 1d — Order ticket, PAPER (modal, step 2 of 2)
**Purpose:** Deliberately effortful confirmation before any simulated order.
**Layout:** 700×780 modal over a dimmed scrim (`background:var(--sunk); opacity:.55`), centered card max-width 620px, warn-colored 1px border + 4px warn top bar.
**Components:** "◐ PAPER MONEY" pill + account id + "STEP 2 OF 2". Title "Place a simulated order for AMD?" + re-check timestamp + ticket expiry countdown. 2×2 stat grid: side/qty, limit entry, protective stop (bad-colored), max loss — footnoted "sent as a bracket… an order without a stop is refused." Confirm row: type-the-ticker input (must match "AMD" exactly) + primary "PLACE PAPER ORDER" + secondary "CANCEL TICKET", helper line "Cancelling costs nothing and keeps the idea approved."

### 1e — Order ticket, LIVE (modal, step 2 of 2)
**Purpose:** Same structure as 1d, deliberately different skin so LIVE is unmistakable even glanced at.
**Layout:** Same modal geometry, but: scrim darker (opacity .72), a diagonal hazard stripe bar (`repeating-linear-gradient(135deg, var(--live) 0 9px, #8a2f26 9px 18px)`) both as a 5px strip above the modal and as a 22px labelled band ("LIVE MONEY", letter-spacing .28em) at the top of the card itself, card border 2px live-red.
**Components:** "▲ REAL FUNDS · IBKR U1043552" pill (dark red fill `#3a1712` / text `#ffb9b1`). Title "Spend real money on AMD?" + explicit "$17,236 of your own cash is committed and the trade cannot be undone from here." Same stat grid, but max-loss cell gets a dark-red fill callout "REAL MONEY AT RISK", and the bracket footnote adds "Slippage past the stop is possible in a gap, so the loss can exceed $893." Confirm row: same type-ticker pattern, but the primary button reads "PLACE LIVE ORDER — $17,236" in the dark-red/live styling (this is the **only** other red fill in the system besides status pills — reserve it for this one button). Extra footnote: "Automated research is not advice. You are the only party deciding to place this order."

### 1f — Watchlist (scan in progress)
**Purpose:** All 27 symbols; demonstrates the multi-minute background scan with per-row state.
**Layout:** Same shell. Header with add-symbol input. Below it, a persistent **scan banner** (accent-bordered box): "◐ SCANNING 11 OF 27", current ticker + stage, elapsed + ETA, "CANCEL SCAN" button, 2-segment progress bar (done + in-progress sliver), and a status-count summary line (complete/in progress/queued/flagged/new ideas/skipped).
**Components:** Table columns TICKER (state glyph ● done / ◐ running / ○ queued / ▲ skip, inline), PRICE, CHG, VOL vs 20d, RSI, SIGNALS, action. Not-yet-scanned rows render dimmed (`color: var(--line2)` for numeric cells) with "—" placeholders. Footer note: "Showing 11 of 27 · rows fill in as the scan reaches them."

### 1g — Journal (thesis accuracy as a first-class view)
**Purpose:** Answer "are the theses right?" — the brief's explicit ask for analytics, not just a win-rate number.
**Layout:** Header with 3M/6M/ALL segmented range control. 5-up KPI strip (corner-marked cards: Approved-by-you, Closed, Win rate, Still open, Avg confidence). Below, `1.35fr 1fr` — a by-month win/loss/scratch stacked bar chart (rate label above each bar, ticker labels below) beside a "win rate by confidence bucket" horizontal-bar list + "by risk-gate verdict" breakdown. Bottom: Recently Closed table (ticker, dir/id, opened→closed dates, confidence, exit price, outcome pill with glyph, note).

### 1h — States catalog (empty / loading / error / safety / legal)
**Purpose:** Not a screen — a 3×2 reference grid of every non-happy-path state the real app hits, so none get improvised later. Implement each as the actual state of its real view, not as a separate page.
**Panels:** (1) Empty state — no ideas yet, dashed frame, "RUN THE FIRST SCAN" CTA. (2) Loading — 3 skeleton triage rows with a "2 of 4 done" caption. (3) Degraded/off provider states — bad/warn/neutral bordered callouts for Finnhub degraded, AI engine off, FRED unconfigured. (4) Order entry ON but broker unreachable — warn-bordered panel explaining the mode is unknown so nothing is treated as paper, plus an example refused-ticket error (price moved 3.1% from plan). (5) Turning order entry ON — the type-ENABLE friction dialog, explicitly naming the account as live; plus a config-error example (`config.yaml` line 34 invalid). (6) Full legal notice — the expanded disclaimer text, opened from the always-present one-line status-bar mention, never a blocking modal.

### 1i — Phone, glance only
**Purpose:** Mobile is read-only by design — the brief says desktop-first, phone-glanceable, and order entry is deliberately unreachable here.
**Layout:** 390×844. Header (title + "● ORDERS OFF" badge + last-scan meta), body (2-up Portfolio/Exposure stat cards, a dashed "orders only on desktop" callout, the same triage-row component stacked, a "4 flagged tickers →" link), bottom tab bar (Today/List/Ideas/Journal, active tab gets top border accent).
**Components:** identical triage-row pattern to 1a but single-column, no confidence bar chart (just the number) to fit width.

### 1i2 — Phone, scan running + LIVE banner
**Purpose:** Shows two things at once: the scan-progress pattern adapted to a narrow width, and how the LIVE hazard treatment reads on mobile (badge only — no ticket UI exists on phone).
**Layout:** Same shell, 5px hazard stripe at the very top of the screen, header badge becomes "▲ ORDERS ON · LIVE" (dark-red fill), meta line names the account. Body: scan-progress card (progress bar, now-ticker, flagged/written counts, CANCEL SCAN button) + a degraded-provider callout + a "written this scan" list using the triage-row pattern minus the verdict/R:R detail.

### 1j — Design tokens & components (reference sheet, not a screen)
Full color, type, spacing, component and new-API-field spec — see **Design Tokens** and **State Management** below, which transcribe it exactly.

## Interactions & Behavior

- **Mode plate** (sidebar footer, every desktop screen): three states — `OFF` (muted dot, "Research only. No orders can be placed.", "Turn on…" link), `ON · PAPER` (warn-colored dot/border/corner-marks, account id, "TURN OFF" button, one click, no confirmation), `ON · LIVE` (not shown standalone in the sidebar in these mocks, but follows the same warn→live color swap; the hazard stripe is reserved for the order ticket and mobile banner, not the sidebar plate). Turning OFF is always one click, no confirmation. Turning ON requires typing `ENABLE` (1h) — this already exists server-side (`POST /api/execution/toggle`, see below).
- **Decision buttons** (1c): exactly one primary per view (Approve). Reject and More-research are secondary/outline, stacked below, same visual weight as each other but subordinate to Approve. No confirmation on any of the three — brief explicitly wants the *safe* directions (reject, turn off) to stay frictionless.
- **Order ticket = modal dialog**, always 2-of-2 (a "prepare" step happens first, silently re-checking price/risk, then this ticket appears). Every ticket: (a) shows a live re-check timestamp, (b) expires (countdown shown), (c) requires typing the exact ticker symbol to submit, (d) always offers a free, instant cancel. LIVE differs from PAPER only in color/copy/border weight — same fields, same steps, same friction mechanism. Never make LIVE's confirm easier than PAPER's.
- **Hazard stripe** (LIVE only): `repeating-linear-gradient(135deg, var(--live) 0 9px, #8a2f26 9px 18px)`. Used at 3 sizes — 5px accent strip (mobile top-of-screen, above modal), 22px labelled band (ticket header). Never used for anything but real-money order flows.
- **Scan progress**: 2-segment bar (solid `--accent-d` for done, lighter `--accent` sliver for the in-progress tick), per-row state glyph (● done / ◐ running / ○ queued / ▲ skip), elapsed + ETA text, always-visible Cancel. Rows fill in live as the scan reaches them (not a spinner-then-pop).
- **Keyboard**: `j`/`k` move through the idea queue, `Enter` opens the focused idea, `a`/`r`/`m` record approve/reject/needs-research. The order-confirmation path intentionally has **no** keyboard shortcut.
- **Focus**: 2px accent ring, 2px offset, on every interactive control, never removed.
- **Status never rests on hue alone** — every status carries a glyph and a word: `●` ok, `◐` in progress, `■` advisory, `▲` failing, `○` unused/neutral.
- **Motion**: the only animating element anywhere is the scan progress bar; it must stop under `prefers-reduced-motion`.
- **Mobile**: order entry is not just hidden but explicitly explained as unreachable ("Orders can only be placed from the desktop app"). No ticket UI exists on phone at all.

## State Management

The backend already exposes `GET /api/state` returning (from `assistant/web/server.py`):
```
disclaimer, ai_ready, providers, base_currency, watchlist_symbols,
scan, scanning, scan_error,
portfolio: { value, positions, exposure_value, exposure_pct, risk_per_trade_pct, max_total_exposure_pct },
ideas, stats, execution, orders
```

**Existing endpoints the design already maps onto directly** (no backend change needed):
| Design action | Endpoint |
|---|---|
| RUN SCAN (1a) | `POST /api/scan` |
| Analyze a ticker (1a) | `POST /api/analyze/<query>` |
| Approve / Needs research / Reject (1c) | `POST /api/ideas/<id>/decision` (`approved`/`needs_research`/`rejected`/`pending`) |
| Log an outcome (referenced in brief; no explicit control seen in 1c — see Open Questions) | `POST /api/ideas/<id>/outcome` (`open`/`win`/`loss`/`scratch`) |
| Turn order entry on/off, incl. the type-ENABLE friction (1h) | `POST /api/execution/toggle` — **already requires** `confirmation: "ENABLE"` server-side when enabling; the mock's flow is not aspirational, it matches current server behavior exactly |
| Prepare ticket (1c → opens 1d/1e) | `POST /api/ideas/<id>/prepare-order` |
| Type-ticker confirm + place (1d/1e) | `POST /api/orders/<id>/confirm` |
| Cancel ticket (1d/1e) | `POST /api/orders/<id>/cancel` |
| Add / remove watchlist symbol (1f) | `POST /api/watchlist/add`, `POST /api/watchlist/remove` |

**New fields/endpoints this design needs** (flagged per the brief's request):
| Field | Why |
|---|---|
| `scan.progress` (`done`/`total`, `current_ticker`, `current_stage`, `started_at`) | Powers the 1f/1i2 progress bar, ETA and per-row state. Today the API only exposes `scanning: true/false`. |
| `POST /api/scan/cancel` | The CANCEL SCAN button (1f, 1i2) has no endpoint yet — no way to stop a running scan today. |
| `idea.stale` | Server-side comparison of plan price to current price, so a 2-day-old plan can be flagged stale in the queue (1a "Attention" panel) without the client re-fetching all 49 ideas. |
| `execution.account_id`, `execution.mode` (`paper`/`live`/`unverified`) | Explicit fields so the UI never infers mode from a port number or similar (the exact bug that already happened once). **Unverified must render as live** — fail closed, never fail open. Extends whatever `execution.execution_status()` currently returns (see `assistant/execution.py`) — additive, not a replacement. |
| `stats.by_verdict`, `stats.by_confidence_bucket` | Win-rate breakdowns for the 1g journal charts. Derivable client-side from `ideas`, but cheaper server-side. Extends `journal.stats()`. |
| `provider.last_error_at` | Timestamp to attach to "last request failed" in degraded-provider callouts (1a, 1h). Extends each entry in `router.provider_status()`. |

**Open question for whoever implements this:** the brief lists outcome logging (open/win/loss/scratch) as a required idea-detail interaction, and `POST /api/ideas/<id>/outcome` already exists for it, but none of the 11 frames show that control explicitly in the 1c rail — worth deciding where it lives (likely a state on the "Your decision" card once an idea is approved and its position closes) before building.

## Design Tokens

**Color** (dark is the default ground per the brief; light is a full parallel set, not an afterthought):

| Token | Dark | Light | Used for |
|---|---|---|---|
| `--bg` | `#12151a` | `#f2f2f3` | App ground |
| `--surface` | `#181c22` | `#e9e9ea` | Cards, tables, rows |
| `--sunk` | `#0f1216` | `#dededf` | Sidebar, status bar, inputs |
| `--line` | `#2a313a` | `#cfcfd1` | Hairline rules |
| `--line2` | `#3a4450` | `#b0b0b3` | Stronger edges, disabled text |
| `--text` | `#e6e9ec` | `#1d1f20` | Body copy |
| `--muted` | `#97a1ad` | `#5d5d60` | Labels, provenance |
| `--accent` | `#94bce3` | `#416180` | Links, focus, in-progress |
| `--accent-d` | `#416180` | `#5980a6` | Primary fill, meters |
| `--accent-dd` | `#1d2d3d` | `#d6ebff` | Active nav tint |
| `--ok` | `#79b389` | `#2f6b41` | Approved, win, provider active |
| `--warn` | `#d5a94f` | `#8a6212` | Advisory flag, PAPER mode |
| `--bad` | `#d2685c` | `#a3372a` | Hard failure, loss, degraded |
| `--live` | `#e2564a` | `#c0342a` | LIVE money only — never used elsewhere |

Note for whoever's implementing: the light-mode values for `--bg` and `--accent-d` (`#f2f2f3`, `#5980a6`) are the same steel-blue-on-paper hue this project's bound Industry design system uses — the light build can lean on that directly. Dark mode extends it with the semantic `ok`/`warn`/`bad`/`live` set Industry's mono palette doesn't define, because a trading app can't rely on a single accent hue for pass/fail/danger states.

**Type:** `--h` = Barlow Condensed 600 (headings, section labels, figures — all tabular-nums where numeric), `--b` = Barlow 400 (body). Scale: page title 26–28px / ticker-figure 18–22px tabular / section label 13–15px at `.13em` tracking / body 15px at 1.62 line-height, max 68ch / table+control text 13px / provenance-timestamp text 11.5–12px. System-ui fallback; **fonts must be vendored into `assistant/web/static/` — no CDN.**

**Spacing scale:** 4 / 8 / 14 / 20 / 26 / 40px.

**Frame:** radius 0 everywhere (square corners, no exceptions). Hairline 1px borders; cards never get a fill beyond the `--surface` step. Corner registration marks (`+`, 11×11px crosshairs, `color: rgba(148,188,227,.5)`, built from two absolutely-positioned 1px lines) appear **only** on the two objects that carry the most weight: the portfolio plate (1a) and the trade-plan card (1c) — plus the primary buttons (RUN SCAN) and KPI cards (1g) in a lighter application. Don't scatter them onto every card.

**Buttons:** one primary per view (solid `--accent-d` fill, white text). Secondary is transparent with a `--line2` border. Disabled drops to a `--line`-bordered, `--line2`-text ghost. The live-order button (dark red `#3a1712` fill, `--live` border, `#ffd3ce` text) is the only other filled/colored button in the system and never appears outside a live order ticket.

## Assets

None. No photography, icons, or icon fonts — status is communicated with plain Unicode glyphs (`● ◐ ■ ▲ ○`) plus a color plus a word, never color alone. This is intentional (accessibility + the brief's "no CDN" constraint) — do not introduce an icon library.

## Files

**In this handoff folder:**
- `Trade Assistant Redesign.dc.html` — the full 11-frame design source (section ids `1a`–`1j` match the screen names above; read the inline `style` attributes for exact values).

**In the design project, not duplicated here (ask for a copy if useful):**
- `Current Dashboard (recreation).dc.html` — a recreation of today's live UI, useful as a before/after diff baseline.

**In your codebase, already in place — these are the integration points:**
- `assistant/web/server.py` — all current Flask routes (see State Management table above).
- `assistant/web/templates/dashboard.html` — the current single-page template this redesign replaces/restructures.
- `assistant/web/__init__.py`
- `assistant/execution.py`, `assistant/journal.py`, `assistant/pipeline.py` — backend logic behind `execution_status()`, `journal.stats()`, and the new fields above.
- `DESIGN_BRIEF.md` — the original brief this design responds to; read it alongside this README for the full rationale (especially the safety constraints section).
